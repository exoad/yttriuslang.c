# Terms of Service v1.5


## Conduct 

Terbius is a bot that is to be used educationally and shall not violate the following policies:
1. No Form of doxxing unless both/all parties agreed for such actions (for commands with coordinates)
2. Stresstesting the bot, overloading the bot, finding exploits along with using those exploits to cause unnecessary security vulnerabilities will not be tolerated
3. General Discord TOS & Guidelines
4. Using the bot as a way to bypass word filters, avoid certain rules, etc. 

If a user is found to be either bending or breaking said policies, warnings and possible excommunications will be enforced, with the possibility of being reported to Discord for such actions that has been deemed unnacceptable. 

## Privacy

The creators of said bot preserves the privacy of all traffic recieved and will not disclose said information for reasons outside of Discord investigations.
This mean, if Discord requests such information from the database, data would be provided for investigations that are deemed critical to the safety of the Discord Community
and the preservation of the Discord Community Guidelines.

However, only interactions with the bot will be tracked with all extraneous info unrelated to said interactions will be ignored or destroyed if necessary. 

## Service Provision

Some services within the bot will have increased capabilities to log certain actions, this means actions such as those requiring a personal sign in or verification will not be tracked however, such as login information, pins, and verification codes will be directly forwarded to the said API. If said info is found to be the logs, it will be destroyed if they are tracked. 

## End Notes

Terbius aims to provide a fun and educational science like to the communities of Discord. Interactions will be tracked in order to help either track the overall usage of commands and to decide the overall popularity of certain commands. 

--END--