Expm.Package.new(name: "exprof", description: "A simple code profiler for Elixir using eprof",
                 version: "0.0.1", keywords: ["Elixir","eprof","profiler"],
                 maintainers: [[name: "parroty", email: "parroty00@gmail.com"]],
                 repositories: [[github: "parroty/exprof"]])
