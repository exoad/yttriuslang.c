defmodule Prof do
  defstruct function: nil, calls: nil, percent: nil, time: nil, us_per_call: nil
end
