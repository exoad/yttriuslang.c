use Mix.Config

config :sugar,
  config_test: [truth: true],
  views_dir: "test/fixtures/templates"
