defmodule SugarTest do
  use ExUnit.Case, async: true

  test "the truth" do
    assert true === true
  end
end
