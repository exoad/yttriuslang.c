defmodule ExscriptTest do
  use ExUnit.Case
  doctest Exscript

  test "the truth" do
    assert 1 + 1 == 2
  end
end
