# Exscript

Very simple library for defining own mix tasks for creating.

The LICENSE and copyright the same as in [elixir](https://github.com/elixir-lang/elixir)

