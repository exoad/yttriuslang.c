git stash push --include-untracked
echo -e "\31m[Dropping stash" ; echo -e "\0m[" ; echo
git stash drop