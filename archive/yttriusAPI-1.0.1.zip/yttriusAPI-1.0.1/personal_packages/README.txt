This folder is only packages on my side and are not used during development of the bot and only so I could easily forward important packages to and from
my server(s).